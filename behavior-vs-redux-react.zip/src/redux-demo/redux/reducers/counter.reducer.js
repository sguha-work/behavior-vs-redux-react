import { createSlice } from "@reduxjs/toolkit";
import { fetchJokeCategories } from "../actions/fetch-joke-categories.action";
const actionList = [fetchJokeCategories];

const counterSlice = createSlice({
  name: "counter",
  initialState: {
    data: null
  },
  extraReducers: (builder) => {
    actionList.forEach((action)=>{
      builder.addCase(action.fulfilled, (state, action) => {
        state.data = action.payload;
      });
    })
  },
});

export default counterSlice.reducer;