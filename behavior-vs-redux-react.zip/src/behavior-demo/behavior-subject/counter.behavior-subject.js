// RxJS v6+
import { BehaviorSubject } from 'rxjs';

const CounterSubject = new BehaviorSubject(null);

export default CounterSubject;