export default function ReduxCounterCompoent () {
    return(
        <h3></h3>
    );
}