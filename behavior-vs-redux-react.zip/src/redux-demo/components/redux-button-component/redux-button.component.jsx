export default function ReduxButtonCompoent () {
    return(
        <>
        <button>Click me to increase value</button>
        </>
    );
}