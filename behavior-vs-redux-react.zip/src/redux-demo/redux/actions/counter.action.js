import { createAsyncThunk } from "@reduxjs/toolkit";
export const fetchCounter = createAsyncThunk("fetchCounter", async () => {
    
    return response;
});